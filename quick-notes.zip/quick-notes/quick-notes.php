<?php
/*
Plugin Name: Quick Notes
Description: Quick User Notes.
Version: 1.0
Author: Alex Maker
Text Domain: quick-notes
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class QuickNotes {
    public function __construct() {
        // Register activation hook to create database table
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Register shortcode to display notes interface
        add_shortcode('quick_notes', array($this, 'render_notes_interface'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        // AJAX actions for creating, deleting, and updating notes
        add_action('wp_ajax_create_note', array($this, 'create_note'));
        add_action('wp_ajax_delete_note', array($this, 'delete_note'));
        add_action('wp_ajax_update_note', array($this, 'update_note'));
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'quick_notes';
        $charset_collate = $wpdb->get_charset_collate();

        // SQL to create table for storing notes
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            title text NOT NULL,
            content text NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
        wp_enqueue_style('quick-notes-style', plugin_dir_url(__FILE__) . 'css/style.css');
        
        // Enqueue jQuery if not already included
        if (!wp_script_is('jquery', 'enqueued')) {
            wp_enqueue_script('jquery');
        }
        
        wp_enqueue_script('axios', 'https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js', array(), null, true);
        wp_enqueue_script('quick-notes-js', plugin_dir_url(__FILE__) . 'js/quick-notes.js', array('jquery', 'axios'), '1.0', true);
        wp_localize_script('quick-notes-js', 'quickNotesData', array(
            'nonce' => wp_create_nonce('quick_notes_nonce'),
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    public function render_notes_interface() {
        // Redirect if user is not logged in
        if (!is_user_logged_in()) {
            wp_redirect(esc_url(site_url('/')));
            exit;
        }

        ob_start(); ?>
        <div class="container container--narrow page-section">
            <div class="create-note">
                <h2 class="headline headline--medium">Create New Note</h2>
                <input class="new-note-title form-control" placeholder="Title">
                <textarea class="new-note-body form-control" placeholder="Your note here..."></textarea>
                <button class="submit-note btn btn-primary mt-2">Create Note</button>
            </div>

            <ul class="min-list link-list" id="quick-notes">
                <?php 
                global $wpdb;
                $user_id = get_current_user_id();
                $results = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, title, content FROM {$wpdb->prefix}quick_notes WHERE user_id = %d", 
                    $user_id
                ));

                // Display existing notes
                foreach ($results as $note) { ?>
                    <li class="fade-in-calc" data-id="<?php echo $note->id; ?>">
                        <input readonly class="note-title-field form-control" value="<?php echo esc_attr($note->title); ?>">
                        <span class="edit-note"><i class="fa fa-pencil" aria-hidden="true"></i> Edit</span>
                        <span class="delete-note"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</span>
                        <textarea readonly class="note-body-field form-control"><?php echo esc_textarea($note->content); ?></textarea>
                        <span class="update-note btn btn--blue btn--small"><i class="fa fa-arrow-right" aria-hidden="true"></i> Save</span>
                    </li>
                <?php } ?>
            </ul>
        </div>
        <?php return ob_get_clean();
    }

    public function create_note() {
        check_ajax_referer('quick_notes_nonce', 'nonce');

        if (is_user_logged_in() && $_POST['title']) {
            global $wpdb;
            $user_id = get_current_user_id();
            $title = sanitize_text_field($_POST['title']);
            $content = sanitize_textarea_field($_POST['content']);

            // Insert new note into database
            $wpdb->insert(
                $wpdb->prefix . 'quick_notes',
                array(
                    'user_id' => $user_id,
                    'title' => $title,
                    'content' => $content
                )
            );
            echo $wpdb->insert_id;
        } else {
            echo "Error creating note.";
        }

        wp_die();
    }

    public function delete_note() {
        check_ajax_referer('quick_notes_nonce', 'nonce');

        if (is_user_logged_in()) {
            global $wpdb;
            $note_id = intval($_POST['id']);
            $user_id = get_current_user_id();

            // Delete note from database
            $wpdb->delete($wpdb->prefix . 'quick_notes', array('id' => $note_id, 'user_id' => $user_id));
        }

        wp_die();
    }

    public function update_note() {
        check_ajax_referer('quick_notes_nonce', 'nonce');

        if (is_user_logged_in()) {
            global $wpdb;
            $note_id = intval($_POST['id']);
            $user_id = get_current_user_id();
            $title = sanitize_text_field($_POST['title']);
            $content = sanitize_textarea_field($_POST['content']);

            // Update note in database
            $wpdb->update(
                $wpdb->prefix . 'quick_notes',
                array(
                    'title' => $title,
                    'content' => $content
                ),
                array(
                    'id' => $note_id, 
                    'user_id' => $user_id
                )
            );
        }

        wp_die();
    }
}

new QuickNotes();