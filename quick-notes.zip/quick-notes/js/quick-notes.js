"use strict";

class MyNotes {
  constructor() {
    this.myNotes = document.querySelector("#quick-notes");
    if (this.myNotes) {
      // Set default headers for Axios
      axios.defaults.headers.common["X-WP-Nonce"] = quickNotesData.nonce;
      this.events();
    }
  }

  events() {
    // Event delegation for buttons within the list
    this.myNotes.addEventListener("click", (e) => {
      const deleteBtn = e.target.closest(".delete-note");
      const editBtn = e.target.closest(".edit-note");
      const updateBtn = e.target.closest(".update-note");

      if (deleteBtn) this.deleteNote(deleteBtn);
      if (editBtn) this.editNote(editBtn);
      if (updateBtn) this.updateNote(updateBtn);
    });

    // Handler for creating a note
    document.querySelector(".submit-note").addEventListener("click", () => this.createNote());
  }

  async deleteNote(deleteBtn) {
    const thisNote = deleteBtn.closest("li");
    const postData = new URLSearchParams();
    postData.append("action", "delete_note");
    postData.append("nonce", quickNotesData.nonce);
    postData.append("id", thisNote.getAttribute("data-id"));

    try {
      // Send request to delete note
      await axios.post(quickNotesData.ajax_url, postData);
      thisNote.remove(); // Remove note from DOM
    } catch (error) {
      console.log("Error deleting the note", error);
    }
  }

  async updateNote(updateBtn) {
    const thisNote = updateBtn.closest("li");
    const title = thisNote.querySelector(".note-title-field").value;
    const content = thisNote.querySelector(".note-body-field").value;

    const postData = new URLSearchParams();
    postData.append("action", "update_note");
    postData.append("nonce", quickNotesData.nonce);
    postData.append("id", thisNote.getAttribute("data-id"));
    postData.append("title", title);
    postData.append("content", content);

    try {
      // Send request to update note
      await axios.post(quickNotesData.ajax_url, postData);
      this.makeNoteReadOnly(thisNote); // Make note read-only
    } catch (error) {
      console.log("Error updating the note", error);
    }
  }

  async createNote() {
    const title = document.querySelector(".new-note-title").value.trim();
    const content = document.querySelector(".new-note-body").value.trim();

    if (!title || !content) {
      console.log("Please enter a title and content for the note.");
      return;
    }

    const postData = new URLSearchParams();
    postData.append("action", "create_note");
    postData.append("nonce", quickNotesData.nonce);
    postData.append("title", title);
    postData.append("content", content);

    try {
      // Send request to create note
      const response = await axios.post(quickNotesData.ajax_url, postData);
      const noteID = response.data;
      const newNote = document.createElement("li");
      newNote.setAttribute("data-id", noteID);
      newNote.innerHTML = `
        <input readonly class="note-title-field form-control" value="${title}">
        <span class="edit-note"><i class="fa fa-pencil" aria-hidden="true"></i> Edit</span>
        <span class="delete-note btn btn-danger mt-2"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</span>
        <textarea readonly class="note-body-field form-control mt-2">${content}</textarea>
        <span class="update-note btn btn-success mt-2"><i class="fa fa-arrow-right" aria-hidden="true"></i> Save</span>
      `;
      this.myNotes.appendChild(newNote);

      // Clear fields for new note entry
      document.querySelector(".new-note-title").value = "";
      document.querySelector(".new-note-body").value = "";
    } catch (error) {
      console.log("Error creating the note", error);
    }
  }

  editNote(editBtn) {
    const thisNote = editBtn.closest("li");
    // Remove readonly and add active class for editing
    thisNote.querySelector(".note-title-field").removeAttribute("readonly");
    thisNote.querySelector(".note-body-field").removeAttribute("readonly");
    thisNote.querySelector(".note-title-field").classList.add("note-active-field");
    thisNote.querySelector(".note-body-field").classList.add("note-active-field");
    thisNote.querySelector(".update-note").classList.add("update-note--visible");
  }

  makeNoteReadOnly(thisNote) {
    // Make note read-only again
    thisNote.querySelector(".edit-note").innerHTML = '<i class="fa fa-pencil" aria-hidden="true"></i> Edit';
    thisNote.querySelector(".note-title-field").setAttribute("readonly", "true");
    thisNote.querySelector(".note-body-field").setAttribute("readonly", "true");
    thisNote.querySelector(".note-title-field").classList.remove("note-active-field");
    thisNote.querySelector(".note-body-field").classList.remove("note-active-field");
    thisNote.querySelector(".update-note").classList.remove("update-note--visible");
  }
}

new MyNotes();